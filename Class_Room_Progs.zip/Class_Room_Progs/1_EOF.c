#include<stdio.h>
int main()
{
	printf("%d\n", EOF);
	return 0;
}
