#include <stdio.h>
int
main ()
{
int n=-123, r=-10 ,reminder,q;
      reminder =  n % r;
      q = n / r;
  printf ("result is = %d\n", reminder);
  printf ("q is = %d\n", q);
  return 0;
}
