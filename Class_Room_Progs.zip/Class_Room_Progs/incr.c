#include <stdio.h>
int main()
{
    int n, i,j;
	i=0;
	j=i++;
	printf(" i is %d ... j is %d \n",i,j)	;


    return 0;
}

