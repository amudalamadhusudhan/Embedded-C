#include <stdio.h> 
int main() 
{
 	int i=1; 
	do
 	{ 
		printf("Value of i is %d\n",i);
 		i++; 
	}
	while(i<=4 && i>=2); 
}

