#include <stdio.h>
int main()
{
	char str1[15] = "cdacacts";
	//char *str2="ram07";

	char str3[6];

	printf("size of str1 = %d\n", sizeof(str1)); //String size or pointer size ???
//	printf("size of str2 = %d\n", sizeof(str2)); //pointer size or pointer size ???

//	str3 = "eDSSD";    //correct or Error or Warning???
//	printf("size of str3 = %d\n", sizeof(str3)); //String size or pointer size ???

    return 0;
}
