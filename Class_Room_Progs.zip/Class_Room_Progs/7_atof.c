/* Using atof function*/
 
#include <stdio.h> 
#include <stdlib.h> 
int main() 
{ 
   double d; 
   d = atof( "199.0"); 
   printf("%f\n", d); //string to float 
   return 0;
} 
