#include <stdio.h> 
int main() 
{ 
	int num[] = {2,8,7,6,0};
 	int i; 
		for(i=0;i<5;i++)
 	{ 
			printf("\nArray Element num[%d] : %d",i+1,num[i]);
 	} 
		return 0;
 }

