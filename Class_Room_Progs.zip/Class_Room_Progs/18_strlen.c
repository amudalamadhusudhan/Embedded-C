#include <stdio.h>
#include<stdlib.h>
#include<string.h>
int main()
{
    char *str = "DSSD";
	printf("Length of string: %d\n",strlen(str));
    return 0;
}
