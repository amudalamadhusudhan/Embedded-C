#include<stdio.h>

int main()
{
	char *num="1465";

	printf("%d\n", atoi(num));

	return 0;
}
