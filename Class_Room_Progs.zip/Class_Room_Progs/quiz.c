#include <stdio.h> 
int main ()
{ 
char name[6] = {'A', 'C', '\0', 'T', 'S', '\0'}; 
printf("message: %s\n", name ); 
return 0; 
}

